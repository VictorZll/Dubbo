package cn.just.service;

import org.dubbo.demo.api.HelloWorld;

public interface HelloWorldService {
	public HelloWorld helloworld(HelloWorld helloWorld);
}
